# omart
This is an online shopping and selling portal where people can buy and sell products.
