<?php
include "./config/config.php";
// if(!isset($_SESSION['user'])){
    header('location:notif.php');
// }
// require_once ("notif.php");
?>